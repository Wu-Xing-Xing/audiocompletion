


addpath(genpath(pwd));